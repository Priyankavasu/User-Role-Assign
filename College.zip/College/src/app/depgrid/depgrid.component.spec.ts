import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DepgridComponent } from './depgrid.component';

describe('DepgridComponent', () => {
  let component: DepgridComponent;
  let fixture: ComponentFixture<DepgridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DepgridComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DepgridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
