import { Component,OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ApiService } from '../api.service';
import { MasterDepartmentComponent } from '../master-department/master-department.component';
import { EditformComponent } from '../editform/editform.component';

@Component({
  selector: 'app-depgrid',
  templateUrl: './depgrid.component.html',
  styleUrl: './depgrid.component.scss'
})
export class DepgridComponent implements OnInit {
  dataSource: any[] = [];

  constructor(private dialog: MatDialog, private apiService: ApiService) {}

  ngOnInit(): void {
    this.apiService.getData().subscribe(data => {
      this.dataSource = data;
    });
  }

  openAddEditForm() {
    this.dialog.open(MasterDepartmentComponent, {
      width: '570px',
      height: '650px'
    });
  }

  openEditForm(item: any) {
    this.dialog.open(EditformComponent, {
      width: '570px',
      height: '650px',
      data: { item }
    });
  }
}




