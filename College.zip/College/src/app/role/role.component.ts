import { Component } from '@angular/core';
interface Option {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrl: './role.component.scss'
})
export class RoleComponent {
  colleges: Option[] = [
    { value: 'options1', viewValue: 'Options 1' },
    { value: 'options2', viewValue: 'Options 2' },
    { value: 'options3', viewValue: 'Options 3' },
  ];

  roles: Option[] = [
    { value: 'student', viewValue: 'Student' },
    { value: 'staff', viewValue: 'Staff' },
    { value: 'superadmin', viewValue: 'Super Admin' },
  ];

  deptList: string[] = ['Option 7', 'Option 8', 'Option 9'];
  programmeList: string[] = ['Option A', 'Option B', 'Option C'];
  batchList: string[] = ['Option 4', 'Option 5', 'Option 6'];

  selectedCollege: string | undefined;
  selectedRole: string = '';
  selectedDept: string | undefined;
  selectedProgramme: string | undefined;
  selectedBatch: string | undefined;

  constructor() {}

  onCollegeChange(): void {
    // Reset selected values
    this.selectedRole = '';
    this.selectedDept = undefined;
    this.selectedProgramme = undefined;
    this.selectedBatch = undefined;
  }

  onRoleChange(): void {
    // Reset selected values based on role change
    this.selectedDept = undefined;
    this.selectedProgramme = undefined;
    this.selectedBatch = undefined;
  }
}
