import { Component } from '@angular/core';
interface Option { 
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrl: './grid.component.scss'
})
export class GridComponent {
  roles: Option[] = [


    { value: 'student', viewValue: 'Student' },
       { value: 'staff', viewValue: 'Staff' },
       { value: 'superadmin', viewValue: 'Super Admin' },
     ];
     selectedRole: string = '';
     onRoleChange(): void {
       // Reset selected values based on role change
      
     }
}
