import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent implements OnInit {
  userForms!: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.userForms = this.fb.group({
      rolestatus: [false], // initial value for mat-slide-toggle
      userrolename: ['', Validators.required], // role name selection with required validator
      description: ['', Validators.required] // description with required validator
    });
  }

  onSubmit(): void {
    // Handle form submission logic here
    if (this.userForms.valid) {
      // Form is valid, proceed with submission
      console.log(this.userForms.value);
    } else {
      // Form is invalid, display error or handle accordingly
      console.error('Form is invalid');
    }
  }
}
