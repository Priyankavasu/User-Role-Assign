import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RopanelComponent } from './ropanel.component';

describe('RopanelComponent', () => {
  let component: RopanelComponent;
  let fixture: ComponentFixture<RopanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RopanelComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RopanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
