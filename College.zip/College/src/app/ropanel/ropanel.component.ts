import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import {MatIconModule} from '@angular/material/icon';
import { DialogComponent } from '../dialog/dialog.component';


@Component({
  selector: 'app-ropanel',
  templateUrl: './ropanel.component.html',
  styleUrl: './ropanel.component.scss'
})
export class RopanelComponent {
  constructor(private _dialog: MatDialog) {
  }

  openAdd() {
    this._dialog.open(DialogComponent);
  }
  

}
