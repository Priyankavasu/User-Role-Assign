import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  updateData(value: any) {
    throw new Error('Method not implemented.');
  }
  baseUrl = 'http://localhost:3000';

  constructor(private _http: HttpClient) { }

  getAllData(): Observable<any> {
    return this._http.get(`${this.baseUrl}/master/getuser_role`).pipe(
      catchError(this.handleError)
    );
  }
  
  createData(data: any): Observable<any> {
    console.log('Data to send:', data);
    return this._http.post(`${this.baseUrl}/master/updateuser_role`, data).pipe(
      catchError(this.handleError)
    );
  }

  getData(): Observable<any[]> {
    return this._http.get<any[]>(`${this.baseUrl}/master/getmaster_dept`)
      .pipe(
        catchError(this.handleError)
      );
  }

  createAllData(data: any): Observable<any> {
    return this._http.post<any>(`${this.baseUrl}/master/updatemaster_dept`, data)
      .pipe(
        catchError(this.handleError)
      );
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'Unknown error!';
    if (error.error instanceof ErrorEvent) {
      // Client-side errors
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side errors
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.error(errorMessage);
    return throwError(errorMessage);
  }
}
