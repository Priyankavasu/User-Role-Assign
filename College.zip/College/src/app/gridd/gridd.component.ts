import { Component } from '@angular/core';
  import { MasterDepartmentComponent } from '../master-department/master-department.component';
  import { MatDialog } from '@angular/material/dialog';
  import { EditformComponent } from '../editform/editform.component';

@Component({
  selector: 'app-gridd',
  templateUrl: './gridd.component.html',
  styleUrl: './gridd.component.scss'
})
export class GriddComponent {
    constructor(private _dialog:MatDialog){}
    openAddEditForm(){
      this._dialog.open(MasterDepartmentComponent,{ width:'700px' ,height:'800px'
      })}
      openEditForm(){
        this._dialog.open(EditformComponent,{ width:'700px' ,height:'800px'
        })
      }
     }
  
  
