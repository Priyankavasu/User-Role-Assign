import { Component,Inject,OnInit } from '@angular/core';
  import { FormBuilder, FormGroup, Validators } from '@angular/forms';
  import { ApiService } from '../api.service';
  import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
@Component({
  selector: 'app-editform',
  templateUrl: './editform.component.html',
  styleUrl: './editform.component.scss'
})
  export class EditformComponent implements OnInit {
    departmentForm: FormGroup;
    years: number[] = [];
  
    constructor(
      private fb: FormBuilder,
      private apiService:ApiService,
      public dialogRef:MatDialogRef<EditformComponent>,
      private apiservice:ApiService,
      @Inject(MAT_DIALOG_DATA) public data: any
  ) {
      console.log(data);
      this.departmentForm = this.fb.group({
        status:[data.item.status],
        DEPARTMENT_CODE: [data.item.DEPARTMENT_CODE, Validators.required],
        DEPARTMENT_NAME: [data.item.DEPARTMENT_NAME, Validators.required],
        DEPARTMENT_ACRONYM: [data.item.DEPARTMENT_ACRONYM, Validators.required],
        DEPARTMENT_YEAR: [data.item.DEPARTMENT_YEAR, Validators.required],
        DEPARTMENT_ACADEMIC: [data.item.DEPARTMENT_ACADEMIC, Validators.required],
        DEPARTMENT_VISION: [data.item.DEPARTMENT_VISION, Validators.required],
        DEPARTMENT_MISION: [data.item.DEPARTMENT_MISION, Validators.required]
      });
    }
  
    ngOnInit(): void {
      const currentYear = new Date().getFullYear();
      for (let year = currentYear; year >= 1900; year--) {
        this.years.push(year);
      }
      if(this.data)
      {
        this.departmentForm.patchValue({
          MASTER_COLLEGE_ID:this.data.item.collegeID,
          MASTER_DEPARTMENT_ID:this.data.item.departmentID,
          STATUS:this.data.item.status,
          DEPARTMENT_CODE:this.data.item.departmentCode,
          DEPARTMENT_NAME:this.data.item.departmentName,
          DEPARTMENT_ACRONYM:this.data.item.departmentAcronym,
          DEPARTMENT_START_YEAR:this.data.item.departmentStartYear,
          ACADEMIC:this.data.item.academic,
          DEPARTMENT_VISION:this.data.item.departmentVision,
          DEPARTMENT_MISSION:this.data.item.departmentMission
      });
      }
    }
  
    onSubmit(): void {
      if (this.departmentForm.valid) {
        console.log(this.departmentForm.value);
        
      }
    }
  }
  
  
