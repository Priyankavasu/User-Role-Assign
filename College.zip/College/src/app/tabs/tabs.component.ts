import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrl: './tabs.component.scss'
})
export class TabsComponent {

  @Input() tabsArray: string[] = [];

  @Output() onTabChange = new EventEmitter<number>();
  activatedTab: number=0;


  setTab(index:number){

    this.activatedTab = index;
    debugger;
    this.onTabChange.emit(this.activatedTab);

  }


}
