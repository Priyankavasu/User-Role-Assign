import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../api.service'; 

@Component({
  selector: 'app-master-department',
  templateUrl: './master-department.component.html',
  styleUrl: './master-department.component.scss'
})


export class MasterDepartmentComponent implements OnInit {
  departmentForm: FormGroup;
  years: number[] = [];

  constructor(private fb: FormBuilder, private departmentService: ApiService) {
    this.departmentForm = this.fb.group({
      STATUS: [1],
      collegeID:1,
      departmentID:null,
      DEPARTMENT_CODE: ['', Validators.required],
      DEPARTMENT_NAME: ['', Validators.required],
      DEPARTMENT_ACRONYM: ['', Validators.required],
      DEPARTMENT_YEAR: ['', Validators.required],
      DEPARTMENT_ACADEMIC: ['', Validators.required],
      DEPARTMENT_VISION: ['', Validators.required],
      DEPARTMENT_MISION: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    const currentYear = new Date().getFullYear();
    for (let year = currentYear; year >= 1900; year--) {
      this.years.push(year);
    }
  }

  onSubmit(): void {
    if (this.departmentForm.valid) {
      console.log(this.departmentForm.value);
      this.departmentForm.get('STATUS')?.setValue(this.departmentForm.get('STATUS')?.value ? 1 : 0);
      this.departmentService.createData(this.departmentForm.value).subscribe(
        res => {
          console.log(res, 'res==>');
          this.departmentForm.reset();
        },
        error => {
          console.error(error);
          // Handle the error here
        }
      );
    }
  }
}

