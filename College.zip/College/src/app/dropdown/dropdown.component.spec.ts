import { Component } from '@angular/core';

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class DropdownComponent {
  options1: string[] = ['Option 1', 'Option 2', 'Option 3'];
  options2: string[] = ['Option A', 'Option B', 'Option C'];

  selectedOption1!: string;
  selectedOption2!: string;
}
