import { Component } from '@angular/core';

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrl: './dropdown.component.scss'
})
export class DropdownComponent {
  selectedOption1: string | null;
  selectedOption2: string | null;

  options1 = ['Option 1', 'Option 2', 'Option 3']; // Add your options
  options2 = ['Suboption 1', 'Suboption 2', 'Suboption 3']; // Add your options

  constructor() {
    this.selectedOption1 = null;
    this.selectedOption2 = null;
  }

  onSelectionChange(): void {
    this.selectedOption2 = null; // Clear second dropdown when first dropdown changes
  }

  onSecondDropdownChange(): void {
    // Handle changes for the second dropdown if needed
  }
}
