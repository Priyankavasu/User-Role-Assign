import { Component } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-master',
  templateUrl: './master.component.html',
  styleUrl: './master.component.scss'
})
export class MasterComponent {

  tabs: string[] = ['College','Department','Programme','Batch & Section','Scheme','Users','Role','Role Assignment'];

  activatedTabIndex: number=0;


  constructor(private router: Router) {}

  tabChange(tabIndex: number) {
    debugger;
    this.activatedTabIndex = tabIndex;
    }
  }






