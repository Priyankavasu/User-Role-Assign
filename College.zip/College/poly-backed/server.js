const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');

const bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const app = express();

// Enable CORS
app.use(cors({
  origin: 'http://localhost:4200', // allow requests from this origin
  credentials: true, // allow credentials (e.g., cookies) to be sent
  methods: ['GET', 'POST', 'PUT', 'DELETE'], // allow these methods
  allowedHeaders: ['Content-Type', 'Authorization'] // allow these headers
}));

// Middleware to parse JSON request bodies
app.use(express.json());

// Create a MySQL connection pool
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'polytechnic'
});

// Define a route for fetching data
app.get('/api/data', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM user_details');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error fetching data' });
  }
});

// Define a route for creating new data
app.post('/api/data', async (req, res) => {
  try {
    const userData = req.body;
    const query = 'INSERT INTO user_details SET ?';
    await pool.execute(query, userData);
    res.json({ message: 'Data created successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error creating data' });
  }
});

// Start the server
const port = 3000;
app.listen(port, () => {
  console.log(Server started on port ${port});
});