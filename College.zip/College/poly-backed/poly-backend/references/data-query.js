var db = require('./database');

module.exports.getCollegeInfo = function (pCallback) {
    let query = `CALL polytechnic.proc_get_college();`;
    db.query(query, pCallback);
}

module.exports.updateCollegeInfo = function (pData, pCallback) {
    let query = `CALL polytechnic.proc_update_college(?);`;
    db.query(query, pData, pCallback);
}

//user_role_assignments
module.exports.getrole_assign = function (pCallback) {
    let query = `CALL polytechnic.proc_get_role_assignments();`;
    db.query(query, pCallback);
}

module.exports.updaterole_assign = function (pData, pCallback) {
    let query = `CALL polytechnic.proc_update_role_assignments(?);`;
    db.query(query, pData, pCallback);
}

//user_role

module.exports.getuser_role = function (pCallback) {
    let query =` CALL polytechnic.proc_get_user_roles();`;
    db.query(query, pCallback);
}

module.exports.updateuser_role = function (pData, pCallback) {
    let query = `CALL polytechnic.proc_update_user_role(?);`;
    db.query(query, pData, pCallback);
}

//master_department

module.exports.getmaster_dept = function (pCallback) {
    let query = `CALL polytechnic.proc_get_departments();`;
    db.query(query, pCallback);
}

module.exports.updatemaster_dept = function (pData, pCallback) {
    let query = `CALL polytechnic.proc_update_department(?);`;
    db.query(query, pData, pCallback);
}

//child_department  
module.exports.getchild_dept = function (pCallback) {
    let query = `CALL polytechnic.proc_get_child_departments();`;
    db.query(query, pCallback);
}

module.exports.updatechild_dept= function (pData, pCallback) {
    let query = `CALL polytechnic.proc_update_child_department(?);`;
    db.query(query, pData, pCallback);
}

//USERS

module.exports.getusers = function (pCallback) {
    let query = `CALL polytechnic.proc_get_users();`;
    db.query(query, pCallback);
}

module.exports.updateusers= function (pData, pCallback) {
    let query = `CALL polytechnic.proc_update_users(?);`;
    db.query(query, pData, pCallback);
}

//MASTER_BATCH

module.exports.getmaster_batch = function (pCallback) {
    let query = `CALL polytechnic.proc_get_batches();`;
    db.query(query, pCallback);
}

module.exports.updatemaster_batch= function (pData, pCallback) {
    let query = `CALL polytechnic.proc_update_batch(?);`;
    db.query(query, pData, pCallback);
}

//CHILD_BATCH

module.exports.getchild_batch = function (pCallback) {
    let query = `CALL polytechnic.proc_get_child_batches();`;
    db.query(query, pCallback);
}

module.exports.updatechild_batch= function (pData, pCallback) {
    let query = `CALL polytechnic.proc_update_child_batch(?);`;
    db.query(query, pData, pCallback);
}

//MASTER_SCHEME

module.exports.getmaster_scheme = function (pCallback) {
    let query = `CALL polytechnic.proc_get_scheme();`;
    db.query(query, pCallback);
}

module.exports.updatemaster_scheme= function (pData, pCallback) {
    let query = `CALL polytechnic.proc_update_scheme(?);`;
    db.query(query, pData, pCallback);
}

//MASTER_PROGRAMME

module.exports.getmaster_programme = function (pCallback) {
    let query = `CALL polytechnic.proc_get_programmes();`;
    db.query(query, pCallback);
}

module.exports.updatemaster_programme= function (pData, pCallback) {
    let query = `CALL polytechnic.proc_update_programme(?);`;
    db.query(query, pData, pCallback);
}

//CHILD_PROGRAMME

module.exports.getchild_programme = function (pCallback) {
    let query = `CALL polytechnic.proc_get_child_programmes();`;
    db.query(query, pCallback);
}

module.exports.updatechild_programme= function (pData, pCallback) {
    let query = `CALL polytechnic.proc_update_child_programme(?);`;
    db.query(query, pData, pCallback);
}

//user details
module.exports.getuser_details= function (pCallback) {
    let query = `CALL polytechnic.proc_get_user_details();`;
    db.query(query, pCallback);
}

module.exports.updateuser_details= function (pData, pCallback) {
    let query = `CALL polytechnic.proc_update_user_details(?);`;
    db.query(query, pData, pCallback);
}

//user login
module.exports.getuser_logins= function (pCallback) {
    let query = `CALL polytechnic.proc_get_user_logins();`;
    db.query(query, pCallback);
}

module.exports.updateuser_logins= function (pData, pCallback) {
    let query = `CALL polytechnic.proc_update_user_logins(?);`;
    db.query(query, pData, pCallback);
}